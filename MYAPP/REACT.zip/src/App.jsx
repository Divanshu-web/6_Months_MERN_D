import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <>
  <div id="div0">
    <div id="body">
      <div id="div1">
        <div id="div2">Wanderlust</div>
        <div id="div3">Home   About   Our Story   Our Members   Gallery</div>
        <div id="div4">Contact</div>
      </div>
      <div className="center">
        <div id="div5">
          <b> Explore The World With Us</b>
          <div id="div6" style={{ textAlign: "center" }}>
            {" "}
            Your journey begins here
          </div>
          <div id="div7" style={{ textAlign: "center", paddingTop: 12 }}>
            <button id="div8">&nbsp;Discover Now&nbsp;</button>
          </div>
        </div>
      </div>
    </div>
    <div className="container">
      Top Destinations
      <div className="row">
        <div id="div9">
          <img src="./image.png" alt="" height="260px" width="415px" />
          <div id="div91">Paris, France</div>
          <div id="div92">The city of lights, romance and culture.</div>
        </div>
        <div id="div10">
          <img src="./image.png" alt="" height="260px" width="415px" />
          <div id="div101">Bali, Indonesia</div>
          <div id="div102">A tropical paradise for your soul and senses.</div>
        </div>
        <div id="div11">
          <img src="./image.png" alt="" height="260px" width="415px" />
          <div id="div111">New York, USA</div>
          <div id="div112">The city that never sleeps.</div>
        </div>
      </div>
    </div>
    <div className="container1">
      <div id="div12"> About Us</div>
      <div id="div13">
        <div id="div14">
          <div id="div140">
            {" "}
            At Wanderlust Travels, we believe every journey should be
            unforgettable. With over 10{" "}
          </div>
          <div id={141}>
            years of experience, we curate personalized travel experience
            tailored to your dreams.
          </div>
          <br />
          <div id="div142">
            {" "}
            From luxurious beach resorts to offbeat mountain trails, we have it
            all covered for your
          </div>{" "}
          next adventure.
        </div>
        <div id="div15">
          <img src="./image.png" alt="" height="400px" width="600px" />
        </div>
      </div>
    </div>
    <div className="container2">
      <div id="div16">Travel Packages</div>
      <div id="div17">
        <div id="div18">
          Budget Explorer
          <div id="div181">
            Perfect for solo travelers or students looking for great
          </div>
          <div id="div182"> value adventures.</div>
          <div id="div183">
            <strong>$499</strong>
          </div>
        </div>
        <div id="div19">
          Couples Retreat
          <div id="div191">A romantic gateway with your partner in exotic</div>
          <div id="div192">destinations.</div>
          <div id="div193">
            <strong>$999</strong>
          </div>
        </div>
        <div id="div20">
          Luxury Package
          <div id="div201">
            5-star stays, private guides, everything first-class.
          </div>
          <div id="div202">
            <strong>$1999</strong>
          </div>
        </div>
      </div>
    </div>
    <div className="container3">
      <div id="div21">What Our Travelers Say</div>
      <div id="div22">
        <div id="div23">
          <div id="div231">"Best travel experience ever! Everything</div>
          <div id="div232">was perfectly arranged."</div>
          <div id="div233">—Ananya Gupta</div>
        </div>
        <div id="div24">
          <div id="div241">"We loved every minute of our Bali trip.</div>
          <div id="div242">Will book again!"</div>
          <div id="div243">—Rohan Mehta</div>
        </div>
        <div id="div25">
          <div id="div251">"Highly professional team and amazing</div>
          <div id="div252">service."</div>
          <div id="div253">—Sarah Khan</div>
        </div>
      </div>
    </div>
    <div id="div26">© 2025 Wanderlust Travels. All Rights Reserved.</div>
  </div>
</>

    </>
  )
}

export default App
