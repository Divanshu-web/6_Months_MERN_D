const mongoose = require('mongoose')

const connectDB = () =>  {
    try{
        mongoose.connect('mongodb+srv://DIVANSHU:DIVANSHU123@projects.3acrp3d.mongodb.net/divanshu?appName=PROJECTS');
        console.log("DB connected successfully!!");
    }
    catch(err){
        console.log("Error Connecting DB: ", err)
    }
}

module.exports = connectDB;