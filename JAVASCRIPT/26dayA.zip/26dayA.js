
function image1(){
    document.getElementById("box1").src="./flower2.png"
}
function come1(){
    document.getElementById("box1").src="./flower1.png"
}

function image2(){
    document.getElementById("box1").src="./flower3.png"
}
function come2(){
    document.getElementById("box1").src="./flower1.png"
}

function image3(){
    document.getElementById("box1").src="./flower4.png"
}
function come3(){
    document.getElementById("box1").src="./flower1.png"
}

function image4(){
    document.getElementById("box1").src="./flower5.png"
}
function come4(){
    document.getElementById("box1").src="./flower1.png"
}
