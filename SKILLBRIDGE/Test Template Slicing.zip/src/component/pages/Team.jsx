// import React from 'react'

function Team() {
  return (
   <>
  {/* Header Start */}
  <div className="container-fluid bg-breadcrumb">
    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
      <h3
        className="text-white display-3 mb-4 wow fadeInDown"
        data-wow-delay="0.1s"
      >
        Our Team
      </h3>
      <ol
        className="breadcrumb justify-content-center mb-0 wow fadeInDown"
        data-wow-delay="0.3s"
      >
        <li className="breadcrumb-item">
          <a href="index.html">Home</a>
        </li>
        <li className="breadcrumb-item">
          <a href="#">Pages</a>
        </li>
        <li className="breadcrumb-item active text-primary">Team</li>
      </ol>
    </div>
  </div>
  {/* Header End */}
  {/* Team Start */}
  <div className="container-fluid team py-5">
    <div className="container py-5">
      <div className="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
        <div className="sub-style">
          <h4 className="sub-title px-3 mb-0">Meet our team</h4>
        </div>
        <h1 className="display-3 mb-4">
          Physiotherapy Services from Professional Therapist
        </h1>
        <p className="mb-0">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat
          deleniti amet at atque sequi quibusdam cumque itaque repudiandae
          temporibus, eius nam mollitia voluptas maxime veniam necessitatibus
          saepe in ab? Repellat!
        </p>
      </div>
      <div className="row g-4 justify-content-center">
        <div
          className="col-md-6 col-lg-6 col-xl-3 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <div className="team-item rounded">
            <div className="team-img rounded-top h-100">
              <img
                src="./assets/img/team-1.jpg"
                className="img-fluid rounded-top w-100"
                alt=""
              />
              <div className="team-icon d-flex justify-content-center">
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-linkedin-in" />
                </a>
              </div>
            </div>
            <div className="team-content text-center border border-primary border-top-0 rounded-bottom p-4">
              <h5>Full Name</h5>
              <p className="mb-0">Message Physio Therapist</p>
            </div>
          </div>
        </div>
        <div
          className="col-md-6 col-lg-6 col-xl-3 wow fadeInUp"
          data-wow-delay="0.3s"
        >
          <div className="team-item rounded">
            <div className="team-img rounded-top h-100">
              <img
                src="./assets/img/team-2.jpg"
                className="img-fluid rounded-top w-100"
                alt=""
              />
              <div className="team-icon d-flex justify-content-center">
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-linkedin-in" />
                </a>
              </div>
            </div>
            <div className="team-content text-center border border-primary border-top-0 rounded-bottom p-4">
              <h5>Full Name</h5>
              <p className="mb-0">Rehabilitation Therapist</p>
            </div>
          </div>
        </div>
        <div
          className="col-md-6 col-lg-6 col-xl-3 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <div className="team-item rounded">
            <div className="team-img rounded-top h-100">
              <img
                src="./assets/img/team-3.jpg"
                className="img-fluid rounded-top w-100"
                alt=""
              />
              <div className="team-icon d-flex justify-content-center">
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-linkedin-in" />
                </a>
              </div>
            </div>
            <div className="team-content text-center border border-primary border-top-0 rounded-bottom p-4">
              <h5>Full Name</h5>
              <p className="mb-0">Doctor of Physical therapy</p>
            </div>
          </div>
        </div>
        <div
          className="col-md-6 col-lg-6 col-xl-3 wow fadeInUp"
          data-wow-delay="0.7s"
        >
          <div className="team-item rounded">
            <div className="team-img rounded-top h-100">
              <img
                src="./assets/img/team-4.jpg"
                className="img-fluid rounded-top w-100"
                alt=""
              />
              <div className="team-icon d-flex justify-content-center">
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
                <a
                  className="btn btn-square btn-primary text-white rounded-circle mx-1"
                  href=""
                >
                  <i className="fab fa-linkedin-in" />
                </a>
              </div>
            </div>
            <div className="team-content text-center border border-primary border-top-0 rounded-bottom p-4">
              <h5>Full Name</h5>
              <p className="mb-0">Doctor of Physical therapy</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Team End */}
</>

  )
}

export default Team
