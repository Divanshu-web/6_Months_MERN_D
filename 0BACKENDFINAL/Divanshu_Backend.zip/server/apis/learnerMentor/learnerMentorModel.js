const mongoose = require('mongoose');

const learnerMentorSchema = new mongoose.Schema({
    autoId:{type: Number, default: 0},
    userId: {type: mongoose.Schema.Types.ObjectId, ref: 'user'},
    contact: { type: Number, default: 0 },
    profession: { type: String, default: "" },
    skills: [{ type: String, default: "" }],
    experience: { type: Number, default: 0 },
    profileImage: { type: String, default: "" },

    isDelete: { type: Boolean, default: false },
    isBlock: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now() },
    updatedAt: { type: Date, default: null }
})

module.exports = mongoose.model('learnerMentor', learnerMentorSchema)