import Header from '../layout/Header'
function About() {

    return (

        <>
        <Header></Header>

            <h1>Satyam</h1>
            <h1>Nikhil</h1>
        </>


    )
}

export default About