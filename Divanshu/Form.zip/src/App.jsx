import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Home from './components/files/Home'
import Form from './components/files/Form'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <Home></Home> */}
       <Form></Form>
    </>
  )
}

export default App
