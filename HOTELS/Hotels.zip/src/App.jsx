import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <div id="body">
          <div className="container-fluid  p-0">
            {/* 1st row */}
            <nav className="navbar navbar-expand-lg navbar-light bg-light px-3 p-3">
              <a className="navbar-brand" href="#">
                <div className="text-dark fw-bold fs-3">Marian</div>
              </a>
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#menu"
              >
                <span className="navbar-toggler-icon" />
              </button>
              <div className="collapse navbar-collapse justify-content-end" id="menu">
                <ul className="navbar-nav align-items-lg-center text-center">
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      Home{" "}
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      About
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      Service{" "}
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      Blog
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      Pages
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link text-dark" href="#">
                      Contact
                    </a>
                  </li>
                  <li className="nav-item mt-2 mt-lg-0 ms-lg-3">
                    <button type="button" className="btn btn-warning text-light">
                      Book Online
                    </button>
                  </li>
                </ul>
              </div>
            </nav>
            <div className="text-center text-light one">
              <div className="fw-bold head   d-flex justify-content-center align-items-center">
                TOP HOTEL IN THE CITY
              </div>
              <div className="fw-medium fs-2 padding d-flex justify-content-center align-items-center">
                Hotel &amp; Resourt
              </div>
            </div>
          </div>
        </div>
        {/* 2nd row  */}
        <div className="head2 text-center fw-bolder pt-5">Our Rooms</div>
        <div className="card-group p-5">
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body ">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
          <div className="ps-4" />
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
          <div className="ps-4" />
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
        </div>
        {/* 3rd row  */}
        <div className="card-group p-5">
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
          <div className="ps-4" />
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
          <div className="ps-4" />
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
            <div className="card-body">
              <h5 className="card-title fw-bold">Classic Double Bed</h5>
              <div className="d-flex">
                <p className="card-text fw-bold">$150</p>
                <p className="card-text fw-medium">
                  <small className="text-body-secondary">/ par night</small>
                </p></div>
            </div>
          </div>
        </div>
        {/* 4th row   */}
        <div className="card-group pt-5">
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
          </div>
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
          </div>
          <div className="card">
            <img src="./image copy 2.png" className="card-img-top" alt="..." />
          </div>
        </div>
        {/* 5th row   */}
        <div className="container-fluid bg-black">
          <div className="row footer">
            <div className="col">
              <div className="text-warning fs-3 fw-medium">Marian</div>
              <div className=" d-flex justify-content-start align-items-center">
                <div className="p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={30}
                    height={30}
                    fill="currentColor"
                    className="bi bi-facebook bg-light text-gray"
                    viewBox="-4 0 25 16"
                  >
                    <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951" />
                  </svg>
                </div>
                <div className="p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={30}
                    height={30}
                    fill="currentColor"
                    className="bi bi-twitter bg-white text-gray"
                    viewBox="-4 0 25 16"
                  >
                    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334q.002-.211-.006-.422A6.7 6.7 0 0 0 16 3.542a6.7 6.7 0 0 1-1.889.518 3.3 3.3 0 0 0 1.447-1.817 6.5 6.5 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.32 9.32 0 0 1-6.767-3.429 3.29 3.29 0 0 0 1.018 4.382A3.3 3.3 0 0 1 .64 6.575v.045a3.29 3.29 0 0 0 2.632 3.218 3.2 3.2 0 0 1-.865.115 3 3 0 0 1-.614-.057 3.28 3.28 0 0 0 3.067 2.277A6.6 6.6 0 0 1 .78 13.58a6 6 0 0 1-.78-.045A9.34 9.34 0 0 0 5.026 15" />
                  </svg>
                </div>
                <div className="p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={30}
                    height={30}
                    fill="currentColor"
                    className="bi bi-globe bg-light text-gray"
                    viewBox="-4 0 25 16"
                  >
                    <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m7.5-6.923c-.67.204-1.335.82-1.887 1.855A8 8 0 0 0 5.145 4H7.5zM4.09 4a9.3 9.3 0 0 1 .64-1.539 7 7 0 0 1 .597-.933A7.03 7.03 0 0 0 2.255 4zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a7 7 0 0 0-.656 2.5zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5zM8.5 5v2.5h2.99a12.5 12.5 0 0 0-.337-2.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5zM5.145 12q.208.58.468 1.068c.552 1.035 1.218 1.65 1.887 1.855V12zm.182 2.472a7 7 0 0 1-.597-.933A9.3 9.3 0 0 1 4.09 12H2.255a7 7 0 0 0 3.072 2.472M3.82 11a13.7 13.7 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5zm6.853 3.472A7 7 0 0 0 13.745 12H11.91a9.3 9.3 0 0 1-.64 1.539 7 7 0 0 1-.597.933M8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855q.26-.487.468-1.068zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.7 13.7 0 0 1-.312 2.5m2.802-3.5a7 7 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7 7 0 0 0-3.072-2.472c.218.284.418.598.597.933M10.855 4a8 8 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4z" />
                  </svg>
                </div>
                <div className="p-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={30}
                    height={30}
                    fill="currentColor"
                    className="bi bi-behance bg-light text-gray"
                    viewBox="-4 0 25 16"
                  >
                    <path d="M4.654 3c.461 0 .887.035 1.278.14.39.07.711.216.996.391s.497.426.641.747c.14.32.216.711.216 1.137 0 .496-.106.922-.356 1.242-.215.32-.566.606-.997.817.606.176 1.067.496 1.348.922s.461.957.461 1.563c0 .496-.105.922-.285 1.278a2.3 2.3 0 0 1-.782.887c-.32.215-.711.39-1.137.496a5.3 5.3 0 0 1-1.278.176L0 12.803V3zm-.285 3.978c.39 0 .71-.105.957-.285.246-.18.355-.497.355-.887 0-.216-.035-.426-.105-.567a1 1 0 0 0-.32-.355 1.8 1.8 0 0 0-.461-.176c-.176-.035-.356-.035-.567-.035H2.17v2.31c0-.005 2.2-.005 2.2-.005zm.105 4.193c.215 0 .426-.035.606-.07.176-.035.356-.106.496-.216s.25-.215.356-.39c.07-.176.14-.391.14-.641 0-.496-.14-.852-.426-1.102-.285-.215-.676-.32-1.137-.32H2.17v2.734h2.305zm6.858-.035q.428.427 1.278.426c.39 0 .746-.106 1.032-.286q.426-.32.53-.64h1.74c-.286.851-.712 1.457-1.278 1.848-.566.355-1.243.566-2.06.566a4.1 4.1 0 0 1-1.527-.285 2.8 2.8 0 0 1-1.137-.782 2.85 2.85 0 0 1-.712-1.172c-.175-.461-.25-.957-.25-1.528 0-.531.07-1.032.25-1.493.18-.46.426-.852.747-1.207.32-.32.711-.606 1.137-.782a4 4 0 0 1 1.493-.285c.606 0 1.137.105 1.598.355.46.25.817.532 1.102.958.285.39.496.851.641 1.348.07.496.105.996.07 1.563h-5.15c0 .58.21 1.11.496 1.396m2.24-3.732c-.25-.25-.642-.391-1.103-.391-.32 0-.566.07-.781.176s-.356.25-.496.39a.96.96 0 0 0-.25.497c-.036.175-.07.32-.07.46h3.196c-.07-.526-.25-.882-.497-1.132zm-3.127-3.728h3.978v.957h-3.978z" />
                  </svg>
                </div>
              </div>
              <div className="text-white">
                Copyright © 2026 All rights <br /> reserved | This template is <br />{" "}
                made with <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width={30}
                  height={30}
                  fill="currentColor"
                  className="bi bi-heart"
                  viewBox="-4 0 25 16"
                >
                  <path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143q.09.083.176.171a3 3 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15" />
                </svg> by colorlib
              </div>
            </div>
            <div className="col">
              <div className="text-light fw-medium fs-5">Quick Links</div>
              <div className="pt-4 text-light">
                About Mariana <br /> Our Best Rooms <br /> Photo Gallery <br />
                Pool Service
              </div>
            </div>
            <div className="col">
              <div className="text-light fw-medium fs-5">Reservation</div>
              <div className="pt-4 text-light">
                Tel:222 3335 558 <br /> Skype: Marinabooking <br />
                reservations@hotelriver.com
              </div>
            </div>
            <div className="col">
              <div className="text-light fw-medium fs-5">Our Location</div>
              <div className="pt-4 text-light">
                198 West 21th Street,
                <br />
                Suite 721 New York NY 10016
                <br />
                reservations@hotelriver.com
              </div>
              <input
                className="form-control form-control-sm"
                style={{width:"250px"}}
                type="text"
                placeholder="Email Address"
                aria-label=".form-control-sm example"
              />

            </div>
          </div>
        </div>
      </div>

    </>
  )
}

export default App
